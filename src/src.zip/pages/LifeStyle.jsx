import React from 'react'

const LifeStyle = () => {
    return (
        <div>LifeStyle</div>
    )
}

export default LifeStyle