import React from 'react'
import { Outlet } from 'react-router-dom'

const Golf = () => {
    return (
        <Outlet />
    )
}

export default Golf