import React from 'react'
import { Outlet } from 'react-router-dom'

const Sundries = () => {
    return (
        <Outlet />
    )
}

export default Sundries