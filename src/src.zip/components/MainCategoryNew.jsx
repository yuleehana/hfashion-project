import React from 'react'

const MainCategoryNew = () => {
    return (
        <section>
            <h2>CATEGORY NEW</h2>
            <div className='container'>
                작업 영역
            </div>
        </section>
    )
}

export default MainCategoryNew