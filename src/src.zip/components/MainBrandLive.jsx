import React from 'react'

const MainBrandLive = () => {
    return (
        <section>
            <h2>MainBrandLive</h2>
            <div className='container'>
                내용
            </div>
        </section>
    )
}

export default MainBrandLive