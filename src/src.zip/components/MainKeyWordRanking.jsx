import React from 'react'

const MainKeyWordRanking = () => {
    return (
        <section>
            <h2>KEYWORD RANKING</h2>
            <div className='container'>
                작업 영역
            </div>
        </section>
    )
}

export default MainKeyWordRanking